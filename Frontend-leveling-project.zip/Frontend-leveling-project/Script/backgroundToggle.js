function setBackground(){
    const hour =new Date().getHours();
    const body = document.body;
    if (hour >= 6 && hour < 18){
        body.classList.add("bg-day");
        body.classList.remove("bg-night");
    }else{
        body.classList.add("bg-night");
        body.classList.remove("bg-day")
    }
}