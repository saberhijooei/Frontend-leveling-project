function setBackground(){
    const hour =new Date().getHours();
    const body = document.body;
    body.classList.remove('bgday' , 'bgnight');
    if (hour >= 6 && hour < 18){

        body.classList.add('bgday');
        
    }else{

        body.classList.add('bgnight');
        
    }
    console.log('Night time : Added bg-night')
}
window.onload = setBackground;